import cProfile, glob, io, pstats, sqlite3, time, timeit
import aq

# ---------- time.perf_counter(): time of each stage ----------
stages = {}
t = time.perf_counter(); aq.write_raw_files("raw_test"); stages["generate 12 files"] = time.perf_counter() - t
t = time.perf_counter(); raw = {p: aq.read_raw_dicts(p) for p in sorted(glob.glob("raw_test/*.csv"))}; stages["read CSV"] = time.perf_counter() - t
t = time.perf_counter(); clean = [aq.clean_rows(r)[0] for r in raw.values()]; stages["clean"] = time.perf_counter() - t
t = time.perf_counter()
con = sqlite3.connect(":memory:"); con.execute("CREATE TABLE r (station TEXT, day TEXT, hour INT, pm25 REAL)")
con.executemany("INSERT INTO r VALUES (?,?,?,?)", [(x["station"], x["date"], x["hour"], x["pm25"]) for rows in clean for x in rows])
stages["store"] = time.perf_counter() - t
t = time.perf_counter(); con.execute("SELECT station, AVG(pm25) FROM r GROUP BY station").fetchall(); stages["query"] = time.perf_counter() - t
print("perf_counter - time of each stage:")
for name, sec in stages.items():
    print(f"   {name:<18}{sec * 1000:8.1f} ms")

# ---------- timeit: compare two ways of writing one small function ----------
def to_float_try(x):
    try:
        return float(x)
    except ValueError:
        return None

def to_float_check(x):
    return float(x) if x.replace(".", "", 1).isdigit() else None

samples = ["48.2", "NA", "", "31.0", "abc", "5000"] * 100
print("\ntimeit - 600 conversions repeated 200 times:")
for fn in (to_float_try, to_float_check):
    t = timeit.timeit(lambda: [fn(s) for s in samples], number=200)
    print(f"   {fn.__name__:<16}{t * 1000:8.1f} ms")

# ---------- cProfile: which function takes the most time ----------
pr = cProfile.Profile(); pr.enable()
for r in raw.values():
    aq.clean_rows(r)
pr.disable()
out = io.StringIO(); pstats.Stats(pr, stream=out).sort_stats("tottime").print_stats(5)
print("\ncProfile of the cleaning stage (top 5 by own time):")
print("\n".join(l for l in out.getvalue().splitlines() if l.strip())[:1200].replace("./", ""))
