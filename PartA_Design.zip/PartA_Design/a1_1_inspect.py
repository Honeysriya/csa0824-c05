import csv, io

RAW = """station,date,hour,pm25,pm10,no2,temp
Adyar,2026-10-01,8,48.2,90.1,31.0,30.5
Adyar,2026-10-01,9,NA,,33.0,31.0
Adyar,2026-10-01,10,52.0,95.0,-5,31.5
Adyar,2026-10-01,10,52.0,95.0,-5,31.5
 ADYAR ,2026-10-01,11,5000,99.0,35.0,32.0
Guindy,2026-10-01,8,95.0,170.0,40.0,86.0
Guindy,01-10-2026,9,98.0,175.0,41.0,87.8
Guindy,2026-10-01,25,60.0,100.0,30.0,80.0
Guindy,2026-10-01,12,4O.2,100.0,30.0,84.0
"""
FAHRENHEIT_STATIONS = {"Guindy", "Velachery"}
problems, seen = {}, set()


def note(kind, line_no, text):
    problems.setdefault(kind, []).append((line_no, text))


for line_no, row in enumerate(csv.DictReader(io.StringIO(RAW)), start=2):
    text = ",".join(row.values())
    name = row["station"]
    if name != " ".join(name.split()).title():
        note("untidy station name", line_no, repr(name))
    d = row["date"]
    if not (len(d) == 10 and d[4] == "-" and d[7] == "-"):
        note("date not yyyy-mm-dd", line_no, d)
    if not (row["hour"].isdigit() and 0 <= int(row["hour"]) <= 23):
        note("invalid hour", line_no, row["hour"])
    key = (name.strip().title(), d, row["hour"])
    if key in seen:
        note("duplicate row", line_no, text)
    seen.add(key)
    for col in ("pm25", "pm10", "no2", "temp"):
        v = row[col].strip()
        if v == "" or v.upper() == "NA":
            note("missing value", line_no, f"{col} = {v!r}")
            continue
        try:
            x = float(v)
        except ValueError:
            note("text in number column", line_no, f"{col} = {v!r}")
            continue
        if col != "temp" and x < 0:
            note("negative value", line_no, f"{col} = {v}")
        if col != "temp" and x > 999:
            note("impossibly large value", line_no, f"{col} = {v}")
        if col == "temp" and x > 45 and name.strip().title() in FAHRENHEIT_STATIONS:
            note("temperature in Fahrenheit", line_no, f"{col} = {v}")

print(f"{'problem':<28}{'count':>6}   first example (line number: value)")
for kind, items in problems.items():
    print(f"{kind:<28}{len(items):>6}   {items[0][0]}: {items[0][1]}")
