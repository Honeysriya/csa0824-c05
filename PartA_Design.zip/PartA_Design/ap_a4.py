import io, logging, sys, time

N = 100000
log = logging.getLogger("clean"); log.propagate = False
sink = io.StringIO()
h = logging.StreamHandler(sink); h.setFormatter(logging.Formatter("%(levelname)s %(message)s")); log.addHandler(h)
real_out = sys.stdout


def run(label, fn):
    t = time.perf_counter(); fn(); dt = time.perf_counter() - t
    return f"{label:<44}{dt:>8.3f} s   ({dt / N * 1e6:.2f} microseconds per call)"


def with_print():
    sys.stdout = io.StringIO()
    for i in range(N): print("row", i, "pm25", 48.2)
    sys.stdout = real_out


DEBUG = False
def print_guarded():
    for i in range(N):
        if DEBUG: print("row", i, "pm25", 48.2)

def logging_on():
    log.setLevel(logging.DEBUG)
    for i in range(N): log.debug("row %d pm25 %s", i, 48.2)

def logging_off():
    log.setLevel(logging.WARNING)
    for i in range(N): log.debug("row %d pm25 %s", i, 48.2)

def nothing():
    for i in range(N): pass

print(f"{N:,} calls")
for lab, fn in (("empty loop (baseline)", nothing), ("print() every row", with_print),
                ("print() inside if DEBUG: (switched off)", print_guarded),
                ("logging.debug, level DEBUG (switched on)", logging_on),
                ("logging.debug, level WARNING (switched off)", logging_off)):
    print(run(lab, fn))
