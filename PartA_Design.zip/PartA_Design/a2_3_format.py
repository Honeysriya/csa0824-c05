from datetime import datetime


def format_date(text):
    """Any of three input formats -> yyyy-mm-dd, or None."""
    for fmt in ("%Y-%m-%d", "%d-%m-%Y", "%d/%m/%Y"):
        try:
            return datetime.strptime(text.strip(), fmt).strftime("%Y-%m-%d")
        except ValueError:
            pass
    return None


def format_station(name):
    """Trim, single spaces, Title Case."""
    return " ".join(name.split()).title()


def format_number(text):
    """Decimal point, one decimal place; blank/NA -> None (NULL)."""
    t = text.strip().replace(",", ".") if text else ""
    if t == "" or t.upper() == "NA":
        return None
    try:
        return round(float(t), 1)
    except ValueError:
        return None


for d in ("2026-10-01", "01-10-2026", "01/10/2026", "Oct 1"):
    print(f"date    {d!r:14} -> {format_date(d)}")
for s in ("  ADYAR ", "t   nagar", "anna nagar"):
    print(f"station {s!r:14} -> {format_station(s)!r}")
for n in ("48.234", "48,2", "NA", "", "abc"):
    print(f"number  {n!r:14} -> {format_number(n)}")
