import sqlite3

con = sqlite3.connect("../Task_B1_Cleaning_Pipeline/aq.db")
con.execute("DROP TABLE IF EXISTS temp.daily_summary")
con.execute("""
CREATE TEMP TABLE daily_summary AS
SELECT s.name AS station, r.day,
       MIN(r.pm25)          AS pm25_min,
       MAX(r.pm25)          AS pm25_max,
       ROUND(AVG(r.pm25),1) AS pm25_mean,
       SUM(1 - r.filled)    AS n_valid
FROM readings r JOIN stations s USING(station_id)
GROUP BY s.name, r.day""")
print("Rows in daily_summary:", con.execute("SELECT COUNT(*) FROM daily_summary").fetchone()[0], "(12 stations x 31 days)")
print(f"\n{'station':<10}{'day':<12}{'min':>6}{'max':>7}{'mean':>7}{'n_valid':>8}")
for row in con.execute("SELECT * FROM daily_summary WHERE station='Adyar' ORDER BY day LIMIT 5"):
    print(f"{row[0]:<10}{row[1]:<12}{row[2]:>6}{row[3]:>7}{row[4]:>7}{row[5]:>8}")
print("\nDays with fewer than 20 measured hours (mean less reliable):",
      con.execute("SELECT COUNT(*) FROM daily_summary WHERE n_valid < 20").fetchone()[0])
