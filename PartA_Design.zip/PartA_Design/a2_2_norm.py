import statistics


def min_max(values):
    lo, hi = min(values), max(values)
    if hi == lo:
        return [0.0] * len(values)
    return [round((v - lo) / (hi - lo), 3) for v in values]


def z_score(values):
    m, s = statistics.mean(values), statistics.pstdev(values)     # population standard deviation
    if s == 0:
        return [0.0] * len(values)
    return [round((v - m) / s, 2) for v in values]


pm25 = [48, 95, 121]
print("PM2.5            :", pm25)
print("min-max (0 to 1) :", min_max(pm25))
print("z-score          :", z_score(pm25), "(mean 88, standard deviation", round(statistics.pstdev(pm25), 1), ")")

# effect of one wrong value (sensor fault) on each method
bad = pm25 + [5000]
print("\nWith one faulty value 5000 added:", bad)
print("min-max :", min_max(bad), " <- all real values squeezed near 0")
print("z-score :", z_score(bad))
