import glob, sqlite3
from collections import defaultdict
import aq

# ---- the cleaned data read from the 12 CSV files ----
rows = []
for path in sorted(glob.glob("../Task_B1_Cleaning_Pipeline/raw_oct/*.csv")):
    rows += aq.clean_rows(aq.read_raw_dicts(path))[0]

# ---- Method 1: from the CSV data with loops ----
tot, cnt = 0.0, 0
for r in rows:
    if r["station"] == "Adyar" and r["pm25"] is not None:
        tot += r["pm25"]; cnt += 1
q1_csv = round(tot / cnt, 1)
st_sum, st_cnt = defaultdict(float), defaultdict(int)
for r in rows:
    st_sum[r["station"]] += r["pm25"]; st_cnt[r["station"]] += 1
q2_csv = sorted(((round(st_sum[s] / st_cnt[s], 1), s) for s in st_sum), reverse=True)[:3]
h_sum, h_cnt = defaultdict(float), defaultdict(int)
for r in rows:
    h_sum[r["hour"]] += r["pm25"]; h_cnt[r["hour"]] += 1
q3_csv = sorted(((round(h_sum[h] / h_cnt[h], 1), h) for h in h_sum), reverse=True)[:3]

# ---- Method 2: SQL queries on the database ----
con = sqlite3.connect("../Task_B1_Cleaning_Pipeline/aq.db")
q1_sql = con.execute("""SELECT ROUND(AVG(r.pm25),1) FROM readings r JOIN stations s USING(station_id)
                        WHERE s.name = ? AND r.day BETWEEN '2026-10-01' AND '2026-10-31'""", ("Adyar",)).fetchone()[0]
q2_sql = [(m, n) for n, m in con.execute("""SELECT s.name, ROUND(AVG(r.pm25),1) AS m FROM readings r
                        JOIN stations s USING(station_id) GROUP BY s.name ORDER BY m DESC LIMIT 3""")]
q3_sql = [(m, h) for h, m in con.execute("SELECT hour, ROUND(AVG(pm25),1) AS m FROM readings GROUP BY hour ORDER BY m DESC LIMIT 3")]

print("Q1 average PM2.5 of Adyar in October :", q1_csv, "(CSV loops) |", q1_sql, "(SQL)")
print("Q2 three highest station means       :", q2_csv, "(CSV loops)\n                                       ", q2_sql, "(SQL)")
print("Q3 three worst hours                 :", q3_csv, "(CSV loops)\n                                       ", q3_sql, "(SQL)")
print("All three answers equal:", q1_csv == q1_sql and q2_csv == q2_sql and q3_csv == q3_sql)
