import sqlite3, statistics
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

con = sqlite3.connect("../Task_B1_Cleaning_Pipeline/aq.db")
plt.rcParams.update({"font.size": 10})

# Question 1: trend over a month -> line chart
d = con.execute("SELECT r.day, AVG(pm25) FROM readings r JOIN stations s USING(station_id) WHERE s.name='Adyar' GROUP BY r.day ORDER BY r.day").fetchall()
plt.figure(figsize=(6, 3)); plt.plot([int(x[8:]) for x, _ in d], [v for _, v in d], "k-o", markersize=3)
plt.title("Line chart: daily mean PM2.5, Adyar"); plt.xlabel("Day of October"); plt.ylabel("PM2.5 (ug/m3)")
plt.tight_layout(); plt.savefig("a3_line.png", dpi=100); plt.close()
print("line chart    ->", "a3_line.png     points:", len(d))

# Question 2: comparison of stations -> box plot
data = {n: [p for (p,) in con.execute("SELECT pm25 FROM readings r JOIN stations s USING(station_id) WHERE s.name=? AND pm25 IS NOT NULL", (n,))]
        for (n,) in con.execute("SELECT name FROM stations")}
names = sorted(data, key=lambda n: statistics.median(data[n]))
plt.figure(figsize=(6, 3)); plt.boxplot([data[n] for n in names], tick_labels=names)
plt.xticks(rotation=60, ha="right", fontsize=7); plt.title("Box plot: PM2.5 by station"); plt.ylabel("PM2.5 (ug/m3)")
plt.tight_layout(); plt.savefig("a3_box.png", dpi=100); plt.close()
print("box plot      ->", "a3_box.png      boxes :", len(names))

# Question 3: temperature and PM2.5 -> scatter plot
pairs = con.execute("SELECT temp_c, pm25 FROM readings WHERE temp_c IS NOT NULL AND pm25 IS NOT NULL").fetchall()
r = statistics.correlation([p[0] for p in pairs], [p[1] for p in pairs])
plt.figure(figsize=(6, 3)); plt.scatter([p[0] for p in pairs][::6], [p[1] for p in pairs][::6], s=4, color="0.3")
plt.title(f"Scatter plot: temperature and PM2.5 (r = {r:.2f})"); plt.xlabel("Temperature (deg C)"); plt.ylabel("PM2.5 (ug/m3)")
plt.tight_layout(); plt.savefig("a3_scatter.png", dpi=100); plt.close()
print("scatter plot  ->", "a3_scatter.png  points:", len(pairs), " r =", round(r, 3))

# Question 4: hours with the worst air -> bar chart
h = con.execute("SELECT hour, AVG(pm25) FROM readings GROUP BY hour ORDER BY hour").fetchall()
plt.figure(figsize=(6, 3)); plt.bar([x for x, _ in h], [v for _, v in h], color="0.4")
plt.title("Bar chart: mean PM2.5 by hour"); plt.xlabel("Hour of the day"); plt.ylabel("PM2.5 (ug/m3)")
plt.tight_layout(); plt.savefig("a3_bar.png", dpi=100); plt.close()
print("bar chart     ->", "a3_bar.png      worst hour:", max(h, key=lambda x: x[1])[0])
