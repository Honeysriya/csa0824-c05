import sqlite3

con = sqlite3.connect("../Task_B1_Cleaning_Pipeline/aq.db")
STATIONS = [n for (n,) in con.execute("SELECT name FROM stations")]
COLUMNS = {"pm2.5": ("pm25", "PM2.5", "ug/m3"), "pm25": ("pm25", "PM2.5", "ug/m3"), "pm10": ("pm10", "PM10", "ug/m3"),
           "no2": ("no2", "NO2", "ug/m3"), "temperature": ("temp_c", "temperature", "deg C")}
LAST_DAY = con.execute("SELECT MAX(day) FROM readings").fetchone()[0]        # "today" = the newest day in the database


def day_before(day):
    return con.execute("SELECT date(?, '-1 day')", (day,)).fetchone()[0]


def chatbot(question):
    q = question.lower()
    if q.split()[0] in ("hello", "hi"):
        return "Hello! Ask for PM2.5, PM10, NO2 or temperature of a station, for example: What is the PM2.5 in Adyar today?"
    station = next((s for s in STATIONS if s.lower() in q), None)
    column = next((c for k, c in COLUMNS.items() if k in q), None)
    day = day_before(LAST_DAY) if "yesterday" in q else LAST_DAY
    if station is None:
        return "Which station do you mean? Stations: " + ", ".join(STATIONS)
    if column is None:
        return "Which reading: PM2.5, PM10, NO2 or temperature?"
    field, name, unit = column                       # field comes from the fixed table above, never from the user text
    value = con.execute(f"SELECT AVG(r.{field}) FROM readings r JOIN stations s USING(station_id) "
                        "WHERE s.name = ? AND r.day = ?", (station, day)).fetchone()[0]
    if value is None:
        return f"No valid {name} reading for {station} on {day}."
    return f"The average {name} in {station} on {day} is {value:.1f} {unit}."


print(f"(newest day in the database, used for 'today': {LAST_DAY})\n")
for q in ["What is the PM2.5 in Adyar today?", "NO2 at Guindy yesterday", "Temperature in Manali today",
          "hello", "What is the PM2.5 today?", "PM2.5 in Adayr today?", "and yesterday?",
          "Compare Adyar and Manali PM2.5 today", "Is it safe to go for a run?"]:
    print("You  :", q)
    print("Bot  :", chatbot(q), "\n")
