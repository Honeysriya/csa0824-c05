import math, random, statistics, time

rnd = random.Random(3)
N = 24 * 365
truth, noise = [], 0.0
for i in range(N):                                   # daily cycle + slowly changing noise (hours are related)
    noise = 0.9 * noise + rnd.gauss(0, 4)
    truth.append(round(60 + 15 * math.sin(2 * math.pi * (i % 24 - 6) / 24) + noise, 1))
data = truth[:]
for _ in range(int(0.06 * N)):                       # 6% single missing readings
    data[rnd.randrange(N)] = None
for _ in range(25):                                  # 25 longer gaps of 6 hours
    s = rnd.randrange(N - 6)
    for i in range(s, s + 6):
        data[i] = None


def daily(values):
    out = []
    for d in range(365):
        part = [v for v in values[d * 24:(d + 1) * 24] if v is not None]
        out.append(sum(part) / len(part) if part else float("nan"))
    return out


def ffill(values, limit=3):
    out, last, gap = [], None, 0
    for v in values:
        if v is None:
            if last is not None and gap < limit:
                out.append(last); gap += 1
            else:
                out.append(None)
        else:
            out.append(v); last = v; gap = 0
    return out


def median_fill(values):
    m = statistics.median(sorted(v for v in values if v is not None))     # sorting: O(n log n)
    return [m if v is None else v for v in values]


true_daily = daily(truth)
print(f"missing readings: {sum(v is None for v in data)} of {N}")
print(f"{'strategy':<28}{'mean error of daily mean':>26}{'time (ms)':>12}")
for name, fn in (("drop (ignore missing)", lambda v: v), ("forward fill (limit 3 h)", ffill), ("median fill", median_fill)):
    t = time.perf_counter(); filled = fn(data); d = daily(filled); dt = (time.perf_counter() - t) * 1000
    err = [abs(a - b) for a, b in zip(d, true_daily) if a == a]
    print(f"{name:<28}{sum(err) / len(err):>26.3f}{dt:>12.2f}")
big = [rnd.random() if rnd.random() > 0.05 else None for _ in range(1000000)]
for name, fn in (("ffill, 1,000,000 values", ffill), ("median fill, 1,000,000 values", median_fill)):
    t = time.perf_counter(); fn(big); print(f"{name:<34}{time.perf_counter() - t:.3f} s")
