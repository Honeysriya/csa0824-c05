import os, sqlite3, time, csv
import pandas as pd

Q_STATION, Q_FROM, Q_TO = "S005", "2026-10-01", "2026-10-31"


def avg_from_csv_every_time():                       # alternative: load the CSV for every question
    df = pd.read_csv("../Task_B3_Loops_vs_Libraries_vs_SQL/data_120.csv")
    m = df[(df["station"] == Q_STATION) & (df["day"] >= Q_FROM) & (df["day"] <= Q_TO)]
    return m["pm25"].mean()


t = time.perf_counter(); r1 = avg_from_csv_every_time(); t_csv = time.perf_counter() - t

df = pd.read_csv("../Task_B3_Loops_vs_Libraries_vs_SQL/data_120.csv")                    # alternative, DataFrame kept in memory
t = time.perf_counter()
m = df[(df["station"] == Q_STATION) & (df["day"] >= Q_FROM) & (df["day"] <= Q_TO)]
r2 = m["pm25"].mean(); t_mem = time.perf_counter() - t
mem_mb = df.memory_usage(deep=True).sum() / 1e6

if os.path.exists("a1.db"): os.remove("a1.db")
con = sqlite3.connect("a1.db")
con.execute("CREATE TABLE aq (station TEXT, day TEXT, hour INTEGER, pm25 REAL)")
with open("../Task_B3_Loops_vs_Libraries_vs_SQL/data_120.csv", newline="") as f:
    r = csv.reader(f); next(r)
    con.executemany("INSERT INTO aq VALUES (?,?,?,?)", ((s, d, int(h), float(v) if v else None) for s, d, h, v in r))
SQL = "SELECT AVG(pm25) FROM aq WHERE station = ? AND day BETWEEN ? AND ?"
t = time.perf_counter(); r3 = con.execute(SQL, (Q_STATION, Q_FROM, Q_TO)).fetchone()[0]; t_scan = time.perf_counter() - t
con.execute("CREATE INDEX idx ON aq(station, day)"); con.commit()
t = time.perf_counter()
for _ in range(100): con.execute(SQL, (Q_STATION, Q_FROM, Q_TO)).fetchone()
t_idx = (time.perf_counter() - t) / 100
con.close()
print("Question: average PM2.5 of one station in one month (1,051,200 rows in total)")
print(f"{'method':<46}{'time per question':>20}")
print(f"{'CSV loaded into pandas for every question':<46}{t_csv * 1000:>17.1f} ms")
print(f"{'DataFrame kept in memory (filter + mean)':<46}{t_mem * 1000:>17.1f} ms")
print(f"{'SQLite, no index (full scan)':<46}{t_scan * 1000:>17.1f} ms")
print(f"{'SQLite, index on (station, day)':<46}{t_idx * 1000:>17.3f} ms")
print(f"\nAll answers equal: {abs(r1 - r2) < 1e-9 and abs(r2 - r3) < 1e-9} ({r1:.3f})")
print(f"CSV file on disk: {os.path.getsize('../Task_B3_Loops_vs_Libraries_vs_SQL/data_120.csv') / 1e6:.0f} MB | DataFrame in memory: {mem_mb:.0f} MB | SQLite file with index: {os.path.getsize('a1.db') / 1e6:.0f} MB")
os.remove("a1.db")
