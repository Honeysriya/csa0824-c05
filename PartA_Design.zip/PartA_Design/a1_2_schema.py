import sqlite3

con = sqlite3.connect(":memory:")
con.execute("PRAGMA foreign_keys = ON")
con.executescript("""
CREATE TABLE stations (
    station_id INTEGER PRIMARY KEY,
    name       TEXT NOT NULL UNIQUE,
    temp_unit  TEXT NOT NULL);
CREATE TABLE readings (
    station_id INTEGER NOT NULL REFERENCES stations(station_id),
    day        TEXT NOT NULL,
    hour       INTEGER NOT NULL,
    pm25 REAL, pm10 REAL, no2 REAL, temp_c REAL,
    filled     INTEGER NOT NULL DEFAULT 0,
    PRIMARY KEY (station_id, day, hour));
""")
for table in ("stations", "readings"):
    print(f"Table {table}: (column, type, not null, primary-key position)")
    for cid, name, typ, notnull, default, pk in con.execute(f"PRAGMA table_info({table})"):
        print(f"   {name:<12}{typ:<10}{notnull}  {pk}")

# one CSV line mapped to the tables
csv_line = "Adyar,2026-10-01,8,48.2,90.1,31.0,30.5".split(",")
con.execute("INSERT INTO stations(name, temp_unit) VALUES (?, 'C')", (csv_line[0],))
sid = con.execute("SELECT station_id FROM stations WHERE name = ?", (csv_line[0],)).fetchone()[0]
row = (sid, csv_line[1], int(csv_line[2]), *map(float, csv_line[3:]), 0)
con.execute("INSERT INTO readings VALUES (?,?,?,?,?,?,?,?)", row)
print("\nStored:", con.execute("SELECT s.name, r.day, r.hour, r.pm25 FROM readings r JOIN stations s USING(station_id)").fetchall())
try:
    con.execute("INSERT INTO readings VALUES (?,?,?,?,?,?,?,?)", row)
except sqlite3.IntegrityError as err:
    print("Same hour inserted twice ->", type(err).__name__ + ":", err)
try:
    con.execute("INSERT INTO readings VALUES (99,'2026-10-01',9,1,1,1,1,0)")
except sqlite3.IntegrityError as err:
    print("Unknown station_id      ->", type(err).__name__ + ":", err)
