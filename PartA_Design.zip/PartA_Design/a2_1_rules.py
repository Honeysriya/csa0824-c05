# One small function for each cleaning rule of Task A2.1, tested on its own.

def forward_fill(values, limit=3):
    """Rule 1: missing value -> previous value, for at most `limit` hours in a row."""
    out, last, gap = [], None, 0
    for v in values:
        if v is None and last is not None and gap < limit:
            out.append(last); gap += 1
        elif v is None:
            out.append(None)
        else:
            out.append(v); last = v; gap = 0
    return out


def remove_impossible(values, low=0, high=999):
    """Rule 2: values outside the possible range become missing (None)."""
    return [v if v is not None and low <= v <= high else None for v in values]


def remove_duplicates(rows):
    """Rule 3: same (station, day, hour) -> keep the first."""
    seen, out = set(), []
    for r in rows:
        if r[:3] not in seen:
            seen.add(r[:3]); out.append(r)
    return out


def fahrenheit_to_celsius(f):
    """Rule 4: C = (F - 32) x 5 / 9, one decimal."""
    return round((f - 32) * 5 / 9, 1)


pm = [48.0, None, None, None, None, 52.0, -5.0, 5000.0, 60.0]
print("Rule 2 impossible values :", pm[5:], "->", remove_impossible(pm[5:]))
step = remove_impossible(pm)
print("Rule 1 forward fill      :", step)
print("                        ->", forward_fill(step), "(limit 3: the 4th missing hour stays None)")
rows = [("Adyar", "2026-10-01", 9, 48.2), ("Adyar", "2026-10-01", 9, 48.2), ("Adyar", "2026-10-01", 10, 50.0)]
print("Rule 3 duplicates        :", len(rows), "rows ->", len(remove_duplicates(rows)), "rows")
print("Rule 4 Fahrenheit        :", [86.0, 95.0, 98.6], "->", [fahrenheit_to_celsius(f) for f in (86.0, 95.0, 98.6)])
