import re
from collections import Counter
from complaints import COMPLAINTS

POSITIVE = {"good", "clean", "fast", "helpful", "improved"}
NEGATIVE = {"bad", "dirty", "slow", "rude", "smoke", "broken"}
NEGATORS = {"not", "never", "no"}
STOP = set("the a an is are was were of to in and or but it its this that for on at by with from as i we you my our "
           "please not no every all again have has had be been will would can cannot do did does so such than then "
           "there their them they he she his her how what when where which who why near after hello sir morning "
           "kindly want".split())


def score(text):
    words = text.lower().replace(".", " ").replace(",", " ").split()
    total = 0
    for i, w in enumerate(words):
        v = 1 if w in POSITIVE else -1 if w in NEGATIVE else 0
        if i > 0 and words[i - 1] in NEGATORS:
            v = -v                                   # negation: "not good" -> -1
        total += v
    return total


def label(text):
    s = score(text)
    return "positive" if s > 0 else "negative" if s < 0 else "neutral"


sentences_of = lambda t: re.split(r"(?<=[.!?])\s+", t.strip())
important = lambda s: [w for w in re.findall(r"[a-z]+", s.lower()) if w not in STOP]
freq = Counter(w for text, _, _ in COMPLAINTS for w in important(text))     # how often each important word occurs


def summarise(text):
    sentences = sentences_of(text)
    scores = [sum(freq[w] for w in set(important(s))) for s in sentences]
    return sentences[scores.index(max(scores))]


print("--- sentiment scorer with negation ---")
for t in ["The road is good.", "The road is not good.", "Not bad, service improved.", "Smoke from the factory, air is bad."]:
    print(f"score {score(t):+d}  {label(t):9}| {t}")
print("\n--- extractive summariser ---")
for t in ["I have lived near the Tondiarpet harbour for ten years. The coal dust covers our cars every morning. Please check the air there.",
          "Burning tyres near the Royapuram bridge. The black smoke covers the whole street. Fire engines were slow to arrive."]:
    print("complaint:", t)
    print("summary  :", summarise(t), "\n")
print("most frequent important words:", freq.most_common(6))
