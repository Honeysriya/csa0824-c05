import io, logging, pdb, sys
import aq


# ---------- 1. print debugging ----------
print("--- print: rows before and after each rule ---")
raw = [{"station": " ADYAR ", "date": "01-10-2026", "hour": "9", "pm25": "NA", "pm10": "5000", "no2": "31", "temp": "86"},
       {"station": "Adyar", "date": "2026-10-01", "hour": "8", "pm25": "48.2", "pm10": "90", "no2": "30", "temp": "30"}]
clean, rep = aq.clean_rows(raw)
print("rows in:", len(raw), "| rows out:", len(clean), "| report:", rep)

# ---------- 2. assert: state what must be true ----------
print("\n--- assert: checks after cleaning ---")
def check(rows):
    keys = set()
    for r in rows:
        assert 0 <= r["hour"] <= 23, f"bad hour {r['hour']}"
        assert r["pm25"] is None or 0 <= r["pm25"] <= 999, f"pm25 out of range: {r['pm25']}"
        assert (r["station"], r["date"], r["hour"]) not in keys, f"duplicate key {r['station'], r['date'], r['hour']}"
        keys.add((r["station"], r["date"], r["hour"]))
    return True
print("clean rows pass all assertions:", check(clean))
broken = clean + [dict(clean[0])]                      # a bug that lets a duplicate through
try:
    check(broken)
except AssertionError as err:
    print("assert caught the bug      : AssertionError:", err)

# ---------- 3. logging with levels ----------
print("\n--- logging: level decides how much is shown ---")
log = logging.getLogger("clean"); log.propagate = False
handler = logging.StreamHandler(sys.stdout); handler.setFormatter(logging.Formatter("%(levelname)-7s %(message)s"))
log.addHandler(handler)
for level in (logging.DEBUG, logging.WARNING):
    log.setLevel(level)
    print(f"level = {logging.getLevelName(level)}")
    log.debug("Guindy 2026-10-01 h9: 87.8 F -> 31.0 C")
    log.info("stage 'clean' finished: 2 rows")
    log.warning("row rejected: hour 25")
log.setLevel(logging.CRITICAL)

# ---------- 4. pdb debugger (commands are given from a script so the session can be shown) ----------
print("\n--- pdb: stop inside a function and look at its variables ---")
def convert(text):
    value = float(text)
    celsius = (value - 32) * 5 / 9
    return round(celsius, 1)

commands = io.StringIO("n\nn\np value\np celsius\nc\n")
debugger = pdb.Pdb(stdin=commands, stdout=sys.stdout)
debugger.use_rawinput = False
print("result:", debugger.runcall(convert, "86.0"))
