import sqlite3, statistics, time

con = sqlite3.connect("../Task_B1_Cleaning_Pipeline/aq.db")

t = time.perf_counter()
sql = {(s, d): (mn, mx, round(m, 6)) for s, d, mn, mx, m in con.execute(
    "SELECT s.name, r.day, MIN(pm25), MAX(pm25), AVG(pm25) FROM readings r JOIN stations s USING(station_id) GROUP BY s.name, r.day")}
t_sql = time.perf_counter() - t

t = time.perf_counter()
groups = {}
for s, d, v in con.execute("SELECT s.name, r.day, r.pm25 FROM readings r JOIN stations s USING(station_id)"):
    if v is not None:
        groups.setdefault((s, d), []).append(v)
loops = {k: (min(v), max(v), round(statistics.mean(v), 6)) for k, v in groups.items()}
t_loops = time.perf_counter() - t

print(f"SQL GROUP BY       : {len(sql)} groups in {t_sql * 1000:.1f} ms")
print(f"Python loops       : {len(loops)} groups in {t_loops * 1000:.1f} ms")
print("Same min, max and mean for every group:", all(abs(a - b) < 1e-6 for k in sql for a, b in zip(sql[k], loops[k])))
