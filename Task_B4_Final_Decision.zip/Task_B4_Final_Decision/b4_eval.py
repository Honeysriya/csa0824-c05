import re, time
from collections import Counter
from complaints import COMPLAINTS
from sentiment import label

# ---------- B4.1a sentiment: scorer against my own reading ----------
print(f"Complaints: {len(COMPLAINTS)}")
wrong = []
for text, mine, _ in COMPLAINTS:
    got = label(text)
    if got != mine:
        wrong.append((mine, got, text))
agree = len(COMPLAINTS) - len(wrong)
print(f"Agreement with my labels: {agree} of {len(COMPLAINTS)} = {100 * agree / len(COMPLAINTS):.1f}%")
cm = Counter((mine, got) for mine, got, _ in wrong)
print("Disagreements (my label -> scorer):", dict(cm))
print("Examples of wrong labels:")
for mine, got, text in wrong[:8]:
    print(f"   mine={mine:8} scorer={got:8} | {text}")

# ---------- B4.1b summariser: most frequent important words ----------
STOP = set("the a an is are was were of to in and or but it its this that for on at by with from as i we you my our "
           "please not no every all again again have has had be been will would can cannot do did does so such "
           "than then there their them they he she his her how what when where which who whom why near after "
           "hello sir morning kindly want".split())
split_sentences = lambda t: re.split(r"(?<=[.!?])\s+", t.strip())
words_of = lambda s: [w for w in re.findall(r"[a-z]+", s.lower()) if w not in STOP]
freq = Counter(w for text, _, _ in COMPLAINTS for w in words_of(text))
print("\nMost frequent important words:", freq.most_common(8))


def summarise_freq(text):
    sents = split_sentences(text)
    scores = [sum(freq[w] for w in set(words_of(s))) for s in sents]
    return scores.index(max(scores))           # index of the chosen sentence (first one on a tie)


def summarise_first(text):
    return 0


multi = [(t, k) for t, _, k in COMPLAINTS if k is not None]
for name, fn in (("frequent words", summarise_freq), ("first sentence", summarise_first)):
    hits = sum(fn(t) == k for t, k in multi)
    print(f"{name:15}: picks the main-point sentence in {hits} of {len(multi)} multi-sentence complaints ({100 * hits / len(multi):.0f}%)")
print("\nExamples (frequent-word summary):")
for t, k in multi[-5:]:
    print("  -", split_sentences(t)[summarise_freq(t)])

# ---------- time for the new scale: 50,000 complaints ----------
texts = [t for t, _, _ in COMPLAINTS] * 834
texts = texts[:50000]
t = time.perf_counter(); [label(x) for x in texts]; ts = time.perf_counter() - t
t = time.perf_counter(); [summarise_freq(x) for x in texts]; tf = time.perf_counter() - t
t = time.perf_counter(); [summarise_first(x) for x in texts]; t1 = time.perf_counter() - t
t2 = time.perf_counter(); [split_sentences(x)[0] for x in texts]; tfirst = time.perf_counter() - t2
print(f"\n50,000 complaints: sentiment {ts:.2f} s | frequent-word summary {tf:.2f} s | first-sentence summary {tfirst:.2f} s (index only: {t1:.3f} s)")
