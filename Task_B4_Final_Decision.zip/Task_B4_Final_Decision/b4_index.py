import sqlite3, csv, time, os

if os.path.exists("big.db"):
    os.remove("big.db")
con = sqlite3.connect("big.db")
con.execute("CREATE TABLE aq (station TEXT, day TEXT, hour INTEGER, pm25 REAL)")
with open("../Task_B3_Loops_vs_Libraries_vs_SQL/data_120.csv", newline="") as f:
    r = csv.reader(f); next(r)
    con.executemany("INSERT INTO aq VALUES (?,?,?,?)",
                    ((s, d, int(h), float(v) if v else None) for s, d, h, v in r))
for prefix in ("B", "C", "D", "E"):                      # 5 x 120 = 600 stations, about 5.3 million rows
    con.execute(f"INSERT INTO aq SELECT '{prefix}' || station, day, hour, pm25 FROM aq WHERE station LIKE 'S%'")
con.commit()
print("Rows in table:", con.execute("SELECT COUNT(*) FROM aq").fetchone()[0])

QUERY = "SELECT AVG(pm25) FROM aq WHERE station = ? AND day BETWEEN '2026-01-01' AND '2026-01-31'"


def timed(n=20):
    t = time.perf_counter()
    for i in range(n):
        res = con.execute(QUERY, (f"S{i % 100:03d}",)).fetchone()[0]
    return (time.perf_counter() - t) / n * 1000, res


print("\nQuery plan without index :", con.execute("EXPLAIN QUERY PLAN " + QUERY, ("S001",)).fetchone()[3])
before, _ = timed(5)
answer_before = con.execute(QUERY, ("S001",)).fetchone()[0]
print(f"Average time per query   : {before:.1f} ms")
t = time.perf_counter()
con.execute("CREATE INDEX idx_station_day ON aq(station, day)")
con.commit()
print(f"\nTime to build the index  : {time.perf_counter() - t:.2f} s")
print("Query plan with index    :", con.execute("EXPLAIN QUERY PLAN " + QUERY, ("S001",)).fetchone()[3])
after, _ = timed(200)
answer_after = con.execute(QUERY, ("S001",)).fetchone()[0]
print(f"Average time per query   : {after:.3f} ms")
print(f"Speed-up                 : {before / after:.0f} times faster; same answer: {answer_before == answer_after}")
print(f"Database file size       : {os.path.getsize('big.db') / 1e6:.0f} MB")
con.close(); os.remove("big.db")
