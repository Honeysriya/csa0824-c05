import math, time, sys
from collections import Counter
from complaints import COMPLAINTS
from sentiment import label as lexicon_label

docs = [(t.lower().replace(".", " ").replace(",", " ").replace("?", " ").split(), y) for t, y, _ in COMPLAINTS]


def train(data):
    prior, words, vocab = Counter(), {}, set()
    for toks, y in data:
        prior[y] += 1
        words.setdefault(y, Counter()).update(toks)
        vocab.update(toks)
    return prior, words, vocab


def predict(model, toks):
    prior, words, vocab = model
    best, best_lp = None, -1e18
    for y in prior:
        total = sum(words[y].values())
        lp = math.log(prior[y] / sum(prior.values()))
        for w in toks:
            lp += math.log((words[y][w] + 1) / (total + len(vocab)))      # Laplace smoothing
        if lp > best_lp:
            best, best_lp = y, lp
    return best


# leave-one-out: train on 62 complaints, test on the remaining one
correct = 0
for i, (toks, y) in enumerate(docs):
    model = train(docs[:i] + docs[i + 1:])
    correct += predict(model, toks) == y
print(f"Naive Bayes, leave-one-out accuracy : {correct} of {len(docs)} = {100 * correct / len(docs):.1f}%")
print(f"Word-list scorer on the same labels : {sum(lexicon_label(t) == y for t, y, _ in COMPLAINTS)} of {len(docs)}")

model = train(docs)
sample = [d[0] for d in docs] * 800
t = time.perf_counter(); [predict(model, toks) for toks in sample[:50000]]; dt = time.perf_counter() - t
print(f"Naive Bayes time for 50,000 complaints: {dt:.2f} s")
words = model[1]
entries = sum(len(c) for c in words.values())
print(f"Model size: {len(model[2])} words in vocabulary, {entries} count entries")
print("Word list size: 15 words")
