from sentiment import score, label      # the scorer completed in Task B4

cases = [
    ("sarcasm",         "Wow, what a wonderful job, the air is so clean that I cannot breathe.", "negative"),
    ("sarcasm",         "Great, another clean and fast day of factory smoke.", "negative"),
    ("double negative", "The service was not unhelpful.", "positive"),
    ("double negative", "It is not that the road is not clean.", "positive"),
    ("double negative", "Not not bad at all.", "negative"),
    ("mixed opinion",   "The roads are clean but the smoke is bad and the staff were rude.", "mixed"),
    ("mixed opinion",   "Bus is fast and helpful, but the stop is dirty.", "mixed"),
    ("negator distance", "The staff were not very helpful.", "negative"),
    ("unknown word",    "The air is terrible and the drains stink.", "negative"),
]
print(f"{'type':16} {'scorer':9} {'true':9} {'ok?':4} sentence")
for kind, text, truth in cases:
    got = label(text)
    ok = "yes" if got == truth else "NO"
    print(f"{kind:16} {got:9} {truth:9} {ok:4} {text}")
