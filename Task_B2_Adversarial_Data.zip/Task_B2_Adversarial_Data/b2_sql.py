import sqlite3

con = sqlite3.connect(":memory:")
con.execute("CREATE TABLE aq (station TEXT, day TEXT, pm25 REAL)")
con.executemany("INSERT INTO aq VALUES (?, ?, ?)", [
    ("Adyar", "2026-10-01", 48.0), ("Guindy", "2026-10-01", 95.0),
    ("Guindy", "2026-10-03", 121.0), ("Adyar", "2026-10-04", 60.0),
    ("St. Thomas' Mount", "2026-10-01", 70.0)])


def by_plus(name):                    # unsafe: string joined with +
    return con.execute("SELECT AVG(pm25) FROM aq WHERE station = '" + name + "'").fetchone()[0]


def by_placeholder(name):             # safe: ? placeholder
    return con.execute("SELECT AVG(pm25) FROM aq WHERE station = ?", (name,)).fetchone()[0]


for name in ("Adyar", "St. Thomas' Mount", "Adyar' OR '1'='1"):
    print(f"Name: {name}")
    try:
        print("   with +           :", by_plus(name))
    except sqlite3.OperationalError as err:
        print("   with +           : OperationalError:", err)
    print("   with ? placeholder:", by_placeholder(name))
con.close()
