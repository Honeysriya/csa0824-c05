"""Shared helpers for the air-quality case study (generation and cleaning)."""
import csv, math, random
from datetime import datetime, date, timedelta

STATIONS = ["Adyar", "Guindy", "Velachery", "T Nagar", "Anna Nagar", "Kodungaiyur",
            "Manali", "Alandur", "Perungudi", "Royapuram", "Sholinganallur", "Tondiarpet"]
FAHRENHEIT = {"Guindy", "Velachery"}            # these two stations report temperature in F
LIMITS = {"pm25": (0, 999), "pm10": (0, 999), "no2": (0, 999), "temp": (-10, 60)}
FIELDS = ["pm25", "pm10", "no2", "temp"]


def to_iso(text):
    for fmt in ("%Y-%m-%d", "%d-%m-%Y", "%d/%m/%Y"):
        try:
            return datetime.strptime(text.strip(), fmt).strftime("%Y-%m-%d")
        except ValueError:
            pass
    return None


def to_float(text):
    t = (text or "").strip()
    if t == "" or t.upper() == "NA":
        return None
    try:
        return float(t)
    except ValueError:
        return None


def clean_rows(rows, ffill_limit=3):
    """rows: list of dicts with raw strings. Returns (clean list of dicts, report dict)."""
    rep = dict(read=len(rows), bad_key=0, duplicates=0, missing=0, impossible=0, fahrenheit=0, filled=0)
    seen, out = set(), []
    for r in rows:
        station = " ".join(r["station"].split()).title()
        day, hour = to_iso(r["date"]), r["hour"].strip()
        if day is None or not hour.isdigit() or not 0 <= int(hour) <= 23:
            rep["bad_key"] += 1
            continue
        key = (station, day, int(hour))
        if key in seen:
            rep["duplicates"] += 1
            continue
        seen.add(key)
        row = {"station": station, "date": day, "hour": int(hour), "filled": 0}
        for f in FIELDS:
            v = to_float(r[f])
            if v is None:
                rep["missing"] += 1
            else:
                if f == "temp" and station in FAHRENHEIT:
                    v = round((v - 32) * 5 / 9, 1)
                    rep["fahrenheit"] += 1
                lo, hi = LIMITS[f]
                if not lo <= v <= hi:
                    rep["impossible"] += 1
                    v = None
            row[f] = v
        out.append(row)
    out.sort(key=lambda r: (r["station"], r["date"], r["hour"]))
    last, gap = {}, {}                          # forward fill, at most ffill_limit hours, per station
    for r in out:
        for f in FIELDS:
            k = (r["station"], f)
            if r[f] is None:
                if k in last and gap[k] < ffill_limit:
                    r[f] = last[k]; gap[k] += 1; r["filled"] = 1; rep["filled"] += 1
            else:
                last[k] = r[f]; gap[k] = 0
    rep["clean"] = len(out)
    return out, rep


def make_raw_rows(station, rnd, days=31, start=date(2026, 10, 1)):
    """Synthetic raw readings with realistic daily pattern and injected faults."""
    base = 35 + 6 * STATIONS.index(station) + (25 if station in ("Manali", "Kodungaiyur") else 0)
    rows = []
    for d in range(days):
        day = start + timedelta(days=d)
        level = base * (1 + 0.25 * math.sin(d / 4.0)) + rnd.gauss(0, 6)
        for h in range(24):
            temp_c = 29 + 5 * math.sin((h - 9) * math.pi / 12) + rnd.gauss(0, 0.8)
            pm25 = max(5, level * (1 + 0.45 * math.exp(-((h - 8) ** 2) / 6) + 0.35 * math.exp(-((h - 21) ** 2) / 8))
                       - 1.2 * (temp_c - 29) + rnd.gauss(0, 5))
            pm10 = pm25 * 1.8 + rnd.gauss(0, 8)
            no2 = 20 + 0.3 * pm25 + rnd.gauss(0, 4)
            temp = temp_c * 9 / 5 + 32 if station in FAHRENHEIT else temp_c
            vals = [pm25, pm10, no2, temp]
            txt = [f"{v:.1f}" for v in vals]
            for i in range(4):                                   # injected faults
                x = rnd.random()
                if x < 0.020: txt[i] = rnd.choice(["", "NA"])
                elif x < 0.025 and i < 3: txt[i] = rnd.choice(["-5", "-999"])
                elif x < 0.028 and i < 3: txt[i] = rnd.choice(["5000", "99999"])
            ds = day.strftime("%d-%m-%Y") if station == "Alandur" else day.isoformat()
            name = station if rnd.random() > 0.01 else "  " + station.upper() + " "
            rows.append([name, ds, str(h)] + txt)
    dup = [list(r) for r in rnd.sample(rows, int(0.01 * len(rows)))]
    rows.extend(dup)
    rnd.shuffle(rows)
    return rows


def write_raw_files(folder, seed=42):
    import os
    os.makedirs(folder, exist_ok=True)
    rnd = random.Random(seed)
    for st in STATIONS:
        with open(os.path.join(folder, st.replace(" ", "_") + ".csv"), "w", newline="", encoding="utf-8") as f:
            w = csv.writer(f)
            w.writerow(["station", "date", "hour", "pm25", "pm10", "no2", "temp"])
            w.writerows(make_raw_rows(st, rnd))


def read_raw_dicts(path):
    with open(path, newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))
