import os, sqlite3, time

rows = lambda n: [(f"S{i % 12}", f"2026-10-{i % 28 + 1:02d}", i * 0.5) for i in range(n)]
print(f"{'n':>8} {'executemany (s)':>16} {'execute loop, one commit (s)':>30}")
for n in (10000, 100000, 1000000):
    data = rows(n)
    res = []
    for mode in ("many", "loop"):
        con = sqlite3.connect(":memory:")
        con.execute("CREATE TABLE aq (station TEXT, day TEXT, pm25 REAL)")
        t = time.perf_counter()
        if mode == "many":
            con.executemany("INSERT INTO aq VALUES (?, ?, ?)", data)
        else:
            for r in data:
                con.execute("INSERT INTO aq VALUES (?, ?, ?)", r)
        con.commit()
        res.append(time.perf_counter() - t)
        con.close()
    print(f"{n:>8} {res[0]:>16.3f} {res[1]:>30.3f}")

# commit after every row on a file database
if os.path.exists("t.db"): os.remove("t.db")
con = sqlite3.connect("t.db")
con.execute("CREATE TABLE aq (station TEXT, day TEXT, pm25 REAL)")
data = rows(500)
t = time.perf_counter()
for r in data:
    con.execute("INSERT INTO aq VALUES (?, ?, ?)", r)
    con.commit()
dt = time.perf_counter() - t
con.close(); os.remove("t.db")
print(f"\nfile database, commit after EVERY row: 500 rows took {dt:.3f} s ({dt / 500 * 1000:.2f} ms per row)")

# the injection input built with an f-string
con = sqlite3.connect(":memory:")
con.execute("CREATE TABLE aq (station TEXT, day TEXT, pm25 REAL)")
con.executemany("INSERT INTO aq VALUES (?, ?, ?)", [("Adyar", "d1", 48.0), ("Guindy", "d1", 95.0), ("Guindy", "d3", 121.0), ("Adyar", "d4", 60.0)])
name = "Adyar' OR '1'='1"
sql = f"SELECT AVG(pm25) FROM aq WHERE station = '{name}'"
print("\nf-string SQL text :", sql)
print("f-string result   :", con.execute(sql).fetchone()[0], "(average of ALL rows)")
print("? placeholder     :", con.execute("SELECT AVG(pm25) FROM aq WHERE station = ?", (name,)).fetchone()[0])
