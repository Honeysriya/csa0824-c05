import csv, io, os

REQUIRED = ["station", "date", "hour", "pm25", "pm10", "no2", "temp"]


def safe_load(path):
    """Returns (rows, message). Never crashes on a bad file."""
    try:
        with open(path, "rb") as f:
            raw = f.read()
    except OSError as err:
        return [], f"cannot open: {err.strerror}"
    if not raw.strip():
        return [], "REJECTED: empty file"
    notes = []
    if raw.startswith((b"\xff\xfe", b"\xfe\xff")):
        text = raw.decode("utf-16"); notes.append("decoded as UTF-16")
    else:
        try:
            text = raw.decode("utf-8-sig")
        except UnicodeDecodeError:
            text = raw.decode("cp1252", errors="replace"); notes.append("not UTF-8, decoded as cp1252")
    try:
        delim = csv.Sniffer().sniff(text.splitlines()[0], delimiters=",;\t|").delimiter
    except csv.Error:
        delim = ","
    if delim != ",":
        notes.append(f"delimiter {delim!r} detected")
    rows = list(csv.DictReader(io.StringIO(text), delimiter=delim))
    missing = [c for c in REQUIRED if c not in (rows[0].keys() if rows else text.splitlines()[0].split(delim))]
    if missing:
        return [], "REJECTED: missing column(s) " + ", ".join(missing)
    return rows, "OK, " + str(len(rows)) + " rows" + ("; " + "; ".join(notes) if notes else "")


good = "station,date,hour,pm25,pm10,no2,temp\nAdyar,2026-10-01,8,48.2,90.1,31.0,30.5\n"
tests = {
    "good.csv": good.encode(),
    "missing_column.csv": b"station,date,hour,pm25,no2,temp\nAdyar,2026-10-01,8,48.2,31.0,30.5\n",
    "semicolon.csv": good.replace(",", ";").encode(),
    "cp1252.csv": (good + "Mylapore \u2013 Kapaleeshwarar,2026-10-01,9,50,95,30,31\n").encode("cp1252"),
    "utf16.csv": good.encode("utf-16"),
    "empty.csv": b"",
}
for name, data in tests.items():
    with open(name, "wb") as f:
        f.write(data)
    rows, msg = safe_load(name)
    print(f"{name:20} -> {msg}")
os.remove("good.csv")
print("nofile.csv           ->", safe_load("nofile.csv")[1])
