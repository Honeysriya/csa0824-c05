import time, tracemalloc, csv
from b3_lib import by_loops


def running_sum(path):
    """One pass: keep only a running sum and a count for every (station, day)."""
    total, count = {}, {}
    with open(path, newline="") as f:
        for r in csv.DictReader(f):
            if r["pm25"] == "":
                continue
            key = (r["station"], r["day"])
            total[key] = total.get(key, 0.0) + float(r["pm25"])
            count[key] = count.get(key, 0) + 1
    return {k: total[k] / count[k] for k in total}


print(f"{'file':>10} {'method':<26} {'time (s)':>9} {'peak memory (MB)':>17}")
for n in (12, 120):
    path = f"data_{n}.csv"
    for name, fn in (("store all + statistics.mean", by_loops), ("running sum and count", running_sum)):
        t = time.perf_counter(); fn(path); dt = time.perf_counter() - t      # time without tracing
        tracemalloc.start(); fn(path)                                          # memory in a second run
        peak = tracemalloc.get_traced_memory()[1] / 1e6; tracemalloc.stop()
        print(f"{n:>3} stations {name:<26} {dt:>9.3f} {peak:>17.1f}")
a, b = by_loops("data_12.csv"), running_sum("data_12.csv")
print("same means:", all(abs(a[k] - b[k]) < 1e-9 for k in a))
