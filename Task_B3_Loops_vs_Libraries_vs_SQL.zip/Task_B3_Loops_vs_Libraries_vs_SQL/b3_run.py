import time
from b3_lib import *

# ---------- B3.1 correctness on small data ----------
generate_csv("small.csv", 3, days=10)
a, b = by_loops("small.csv"), by_pandas("small.csv")
c = sql_query(load_sql("small.csv"))
print("B3.1  groups (station, day):", len(a), len(b), len(c))
same = all(abs(a[k] - b[k]) < 1e-9 and abs(a[k] - c[k]) < 1e-9 for k in a) and a.keys() == b.keys() == c.keys()
print("      loops == pandas == SQL (tolerance 1e-9):", same)
k = ("S000", "2026-01-01")
print("      example", k, "->", round(a[k], 4), round(b[k], 4), round(c[k], 4))

# ---------- B3.2 increase the data size ----------
print(f"\nB3.2  {'stations':>8} {'rows':>9} {'loops (s)':>10} {'pandas (s)':>11} {'SQL total (s)':>14} {'SQL query only (s)':>19}")
for n in (1, 12, 120):
    path = f"data_{n}.csv"
    generate_csv(path, n)
    t = time.perf_counter(); by_loops(path); t_loops = time.perf_counter() - t
    t = time.perf_counter(); by_pandas(path); t_pd = time.perf_counter() - t
    t = time.perf_counter(); con = load_sql(path); t_load = time.perf_counter() - t
    t = time.perf_counter(); sql_query(con); t_q = time.perf_counter() - t
    rows = n * 365 * 24
    print(f"      {n:>8} {rows:>9} {t_loops:>10.3f} {t_pd:>11.3f} {t_load + t_q:>14.3f} {t_q:>19.3f}")
