import csv, sqlite3, statistics
from datetime import date, timedelta
import numpy as np
import pandas as pd


def generate_csv(path, n_stations, days=365, seed=7):
    """station,day,hour,pm25 - about 8,760 readings per station; 2% blank readings."""
    rng = np.random.default_rng(seed)
    start = date(2026, 1, 1)
    day_names = [(start + timedelta(days=d)).isoformat() for d in range(days)]
    with open(path, "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["station", "day", "hour", "pm25"])
        for s in range(n_stations):
            base = 40 + 3 * (s % 20)
            vals = np.round(base + 25 * rng.random((days, 24)), 1)
            blank = rng.random((days, 24)) < 0.02
            for d in range(days):
                for h in range(24):
                    w.writerow([f"S{s:03d}", day_names[d], h, "" if blank[d, h] else vals[d, h]])


# ---------- method 1: plain Python loops with the csv module ----------
def read_rows(path):
    with open(path, newline="") as f:
        for row in csv.DictReader(f):
            yield row


def group_readings(rows):
    groups = {}
    for r in rows:
        if r["pm25"] == "":
            continue
        groups.setdefault((r["station"], r["day"]), []).append(float(r["pm25"]))
    return groups


def daily_means(groups):
    return {key: statistics.mean(vals) for key, vals in groups.items()}


def by_loops(path):
    return daily_means(group_readings(read_rows(path)))


# ---------- method 2: pandas groupby ----------
def by_pandas(path):
    df = pd.read_csv(path)
    return df.groupby(["station", "day"])["pm25"].mean().to_dict()


# ---------- method 3: SQL GROUP BY ----------
def load_sql(path):
    con = sqlite3.connect(":memory:")
    con.execute("CREATE TABLE aq (station TEXT, day TEXT, hour INTEGER, pm25 REAL)")
    with open(path, newline="") as f:
        r = csv.reader(f)
        next(r)
        con.executemany("INSERT INTO aq VALUES (?, ?, ?, ?)",
                        ((s, d, int(h), float(v) if v != "" else None) for s, d, h, v in r))
    con.commit()
    return con


def sql_query(con):
    return {(s, d): m for s, d, m in con.execute("SELECT station, day, AVG(pm25) FROM aq GROUP BY station, day")}
