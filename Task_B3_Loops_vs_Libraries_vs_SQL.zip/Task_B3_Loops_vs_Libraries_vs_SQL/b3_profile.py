import cProfile, pstats
from b3_lib import by_loops

cProfile.run('by_loops("data_12.csv")', "prof.out")
p = pstats.Stats("prof.out")
p.sort_stats("tottime").print_stats(6)
