import glob, os, sqlite3, statistics
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import aq
import os
os.makedirs("charts", exist_ok=True)

IMG = "charts"
plt.rcParams.update({"axes.prop_cycle": plt.cycler(color=["black", "0.4", "0.6"]), "font.size": 10})

# ---------- acquire + clean ----------
aq.write_raw_files("raw_oct")
rows, total = [], {}
for path in sorted(glob.glob("raw_oct/*.csv")):
    clean, rep = aq.clean_rows(aq.read_raw_dicts(path))
    rows += clean
    for k, v in rep.items():
        total[k] = total.get(k, 0) + v
print("Cleaning report for 12 station files:", total)

# ---------- store (executemany) ----------
if os.path.exists("aq.db"):
    os.remove("aq.db")
con = sqlite3.connect("aq.db")
con.executescript("""
CREATE TABLE stations (station_id INTEGER PRIMARY KEY, name TEXT NOT NULL UNIQUE, temp_unit TEXT NOT NULL);
CREATE TABLE readings (
    station_id INTEGER NOT NULL REFERENCES stations(station_id),
    day TEXT NOT NULL, hour INTEGER NOT NULL,
    pm25 REAL, pm10 REAL, no2 REAL, temp_c REAL, filled INTEGER NOT NULL DEFAULT 0,
    PRIMARY KEY (station_id, day, hour));
""")
con.executemany("INSERT INTO stations(name, temp_unit) VALUES (?, ?)",
                [(s, "F" if s in aq.FAHRENHEIT else "C") for s in aq.STATIONS])
ids = dict(con.execute("SELECT name, station_id FROM stations"))
con.executemany("INSERT INTO readings VALUES (?,?,?,?,?,?,?,?)",
                [(ids[r["station"]], r["date"], r["hour"], r["pm25"], r["pm10"], r["no2"], r["temp"], r["filled"])
                 for r in rows])
con.commit()
print("Rows stored:", con.execute("SELECT COUNT(*) FROM readings").fetchone()[0])

# ---------- three questions of the board ----------
q1 = con.execute("""SELECT ROUND(AVG(r.pm25),1) FROM readings r JOIN stations s USING(station_id)
                    WHERE s.name = ? AND r.day BETWEEN '2026-10-01' AND '2026-10-31'""", ("Adyar",)).fetchone()[0]
print("\nQ1 Average PM2.5 of Adyar in October:", q1)
print("Q2 Stations ranked by mean PM2.5 (highest 3, lowest 2):")
rank = con.execute("""SELECT s.name, ROUND(AVG(r.pm25),1) FROM readings r JOIN stations s USING(station_id)
                      GROUP BY s.name ORDER BY 2 DESC""").fetchall()
for n, v in rank[:3] + rank[-2:]:
    print(f"   {n:16}{v}")
print("Q3 Three hours with the worst average PM2.5:")
for h, v in con.execute("SELECT hour, ROUND(AVG(pm25),1) FROM readings GROUP BY hour ORDER BY 2 DESC LIMIT 3"):
    print(f"   hour {h:02d}:00  {v}")
print("\nDaily summary table, Adyar, first 5 days (min, max, mean, valid readings):")
for rec in con.execute("""SELECT r.day, MIN(pm25), MAX(pm25), ROUND(AVG(pm25),1), SUM(1 - filled)
                          FROM readings r JOIN stations s USING(station_id) WHERE s.name='Adyar'
                          GROUP BY r.day ORDER BY r.day LIMIT 5"""):
    print("  ", rec)

# ---------- charts ----------
daily = con.execute("""SELECT r.day, AVG(pm25) FROM readings r JOIN stations s USING(station_id)
                       WHERE s.name='Adyar' GROUP BY r.day ORDER BY r.day""").fetchall()
days = [int(d[8:]) for d, _ in daily]; vals = [v for _, v in daily]
plt.figure(figsize=(7, 3.4)); plt.plot(days, vals, color="black", marker="o", markersize=3)
plt.axhline(60, color="0.5", linestyle="--", label="24-hour standard 60")
plt.title("Chart 1: Daily mean PM2.5 at Adyar, October 2026"); plt.xlabel("Day of October"); plt.ylabel("PM2.5 (ug/m3)")
plt.legend(); plt.tight_layout(); plt.savefig(f"{IMG}/chart1.png", dpi=150); plt.close()
print("\nChart 1 data: highest day", max(zip(vals, days)), "lowest day", min(zip(vals, days)))

by_st = {}
for r in rows:
    if r["pm25"] is not None:
        by_st.setdefault(r["station"], []).append(r["pm25"])
order = sorted(by_st, key=lambda s: statistics.median(by_st[s]))
plt.figure(figsize=(7.5, 3.8))
plt.boxplot([by_st[s] for s in order], tick_labels=order, medianprops=dict(color="black"), boxprops=dict(color="0.3"),
            flierprops=dict(markersize=2, markeredgecolor="0.5"))
plt.xticks(rotation=45, ha="right"); plt.title("Chart 2: PM2.5 by station, October 2026"); plt.ylabel("PM2.5 (ug/m3)")
plt.tight_layout(); plt.savefig(f"{IMG}/chart2.png", dpi=150); plt.close()
print("Chart 2 medians: lowest", order[0], round(statistics.median(by_st[order[0]]), 1),
      "| highest", order[-1], round(statistics.median(by_st[order[-1]]), 1))

pairs = [(r["temp"], r["pm25"]) for r in rows if r["temp"] is not None and r["pm25"] is not None]
x, y = [p[0] for p in pairs], [p[1] for p in pairs]
corr = statistics.correlation(x, y)
plt.figure(figsize=(6.5, 3.8)); plt.scatter(x[::6], y[::6], s=4, color="0.3")
plt.title(f"Chart 3: Temperature and PM2.5 (r = {corr:.2f})"); plt.xlabel("Temperature (deg C)"); plt.ylabel("PM2.5 (ug/m3)")
plt.tight_layout(); plt.savefig(f"{IMG}/chart3.png", dpi=150); plt.close()
print("Chart 3 correlation r =", round(corr, 3), "from", len(pairs), "pairs")

hours = con.execute("SELECT hour, AVG(pm25) FROM readings GROUP BY hour ORDER BY hour").fetchall()
plt.figure(figsize=(7, 3.4)); plt.bar([h for h, _ in hours], [v for _, v in hours], color="0.35")
plt.title("Chart 4: Mean PM2.5 by hour of the day"); plt.xlabel("Hour of the day"); plt.ylabel("PM2.5 (ug/m3)")
plt.tight_layout(); plt.savefig(f"{IMG}/chart4.png", dpi=150); plt.close()
print("Chart 4: best hour", min((v, h) for h, v in hours), "worst hour", max((v, h) for h, v in hours))
con.close()
