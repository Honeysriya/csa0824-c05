import csv, io, random, time, tracemalloc
import pandas as pd


def make_text(n):
    rnd = random.Random(1)
    out = ["station,date,pm25"]
    for i in range(n):
        x = rnd.random()
        v = "NA" if x < 0.03 else "" if x < 0.05 else "-5" if x < 0.06 else "5000" if x < 0.07 else f"{rnd.uniform(10, 200):.1f}"
        out.append(f"Adyar,2026-10-{i % 28 + 1:02d},{v}")
    return "\n".join(out)


def loops(text):
    vals = []
    for r in csv.DictReader(io.StringIO(text)):
        v = r["pm25"].strip()
        if v == "" or v.upper() == "NA":
            continue
        v = float(v)
        if 0 <= v <= 999:
            vals.append(v)
    lo, hi = min(vals), max(vals)
    return [(v - lo) / (hi - lo) for v in vals]


def with_pandas(text):
    df = pd.read_csv(io.StringIO(text), na_values=["NA", ""])
    df = df.dropna(subset=["pm25"])
    df = df[(df["pm25"] >= 0) & (df["pm25"] <= 999)]
    return (df["pm25"] - df["pm25"].min()) / (df["pm25"].max() - df["pm25"].min())


print(f"{'rows':>10} {'method':<8} {'time (s)':>9} {'peak memory (MB)':>17} {'rows kept':>10}")
for n in (1000, 100000, 1000000):
    text = make_text(n)
    for fn in (loops, with_pandas):
        tracemalloc.start()
        t = time.perf_counter()
        res = fn(text)
        dt = time.perf_counter() - t
        peak = tracemalloc.get_traced_memory()[1] / 1e6
        tracemalloc.stop()
        print(f"{n:>10} {fn.__name__:<8} {dt:>9.4f} {peak:>17.1f} {len(res):>10}")
