import aq

RAW = """station,date,hour,pm25,pm10,no2,temp
Adyar,2026-10-01,8,48.2,90.1,31.0,30.5
Adyar,2026-10-01,9,NA,,33.0,31.0
Adyar,2026-10-01,10,52.0,95.0,-5,31.5
Adyar,2026-10-01,10,52.0,95.0,-5,31.5
 ADYAR ,2026-10-01,11,5000,99.0,35.0,32.0
Guindy,2026-10-01,8,95.0,170.0,40.0,86.0
Guindy,01-10-2026,9,98.0,175.0,41.0,87.8
Guindy,2026-10-01,25,60.0,100.0,30.0,80.0
"""
rows = list(__import__("csv").DictReader(RAW.splitlines()))
print("BEFORE cleaning (raw text, 8 lines):")
for r in rows:
    print(f"  {r['station']!r:10} {r['date']:11} h={r['hour']:>2}  pm25={r['pm25']!r:7} pm10={r['pm10']!r:6} no2={r['no2']!r:5} temp={r['temp']}")
clean, rep = aq.clean_rows(rows)
print("\nAFTER cleaning:")
for r in clean:
    print(f"  {r['station']:8} {r['date']} h={r['hour']:>2}  pm25={r['pm25']} pm10={r['pm10']} no2={r['no2']} temp={r['temp']} filled={r['filled']}")
print("\nReport:", rep)
